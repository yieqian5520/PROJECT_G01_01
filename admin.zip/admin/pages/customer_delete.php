<?php
require_once __DIR__ . '/../partials/auth_guard.php';
require_once __DIR__ . '/../config/db.php';
