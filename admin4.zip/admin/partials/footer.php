<?php
// /admin/partials/footer.php
?>
<footer class="app-footer">
  <div class="float-end d-none d-sm-inline">Admin Panel</div>
  <strong>
    Copyright &copy; <?= date('Y') ?>
    <a href="#" class="text-decoration-none">Pucks Coffee</a>.
  </strong>
  All rights reserved.
</footer>
